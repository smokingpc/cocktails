#pragma once
#include <tchar.h>
#include <Windows.h>
#include <strsafe.h>
#include <stdio.h>

#include "Service.h"
#include "EventMessage.h"
